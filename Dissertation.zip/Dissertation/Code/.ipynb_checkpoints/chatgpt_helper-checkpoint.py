import numpy as np
import pandas as pd
from collections import defaultdict
from sklearn import preprocessing

df = pd.ExcelFile(r'..\Resources\Data\raw.xlsx').parse('compas-scores-two-years')

def preprocess_data(df, cat_features, cont_features, target, protected_feature):
    # Convert DataFrame to NumPy arrays
    data = {k: np.array(v) for k, v in df.to_dict('list').items()}
    
    # Convert class labels from 0 to -1
    y = np.where(data[target] == 0, -1, data[target])
    
    # Initialize feature matrix and tracking dictionaries
    X = np.empty((len(y), 0))
    x_control = defaultdict(list)
    feature_names = []

    # Process features
    for attr in cat_features:
        vals = data[attr]
        
        if attr in cont_features:
            # Scale continuous features
            vals = preprocessing.scale(vals).reshape(-1, 1)
            feature_names.append(attr)
        else:
            # Encode categorical features
            lb = preprocessing.LabelBinarizer()
            vals = lb.fit_transform(vals)
            feature_names.extend([f"{attr}_{label}" for label in lb.classes_])
        
        # Append to feature matrix
        X = np.hstack((X, vals))

        # Track sensitive features
        if attr == protected_feature:
            x_control[attr] = vals.flatten()

    return X, y, x_control, feature_names

cat_features = ["age_cat", "race", "sex", "priors_count", "c_charge_degree"]
cont_features = ["priors_count"]
target = "two_year_recid"
protected_feature = "race"

X, y, x_control, feature_names = preprocess_data(df, cat_features, cont_features, target, protected_feature)
print(x_control)
print(X.shape)
print(y.shape)
print(feature_names)

def split_into_train_test(x_all, y_all, x_control_all, train_size):
    split_point = int(round(x_all.shape[0] * train_size))
    
    # Split the main data
    x_all_train, x_all_test = x_all[:split_point], x_all[split_point:]
    y_all_train, y_all_test = y_all[:split_point], y_all[split_point:]
    
    # Split the control data
    x_control_all_train = {k: v[:split_point] for k, v in x_control_all.items()}
    x_control_all_test = {k: v[split_point:] for k, v in x_control_all.items()}
    
    return x_all_train, y_all_train, x_control_all_train, x_all_test, y_all_test, x_control_all_test

def split(x_all, y_all, train_size):
    split_point = int(round(x_all.shape[0] * train_size))
    
    x_all_train, x_all_test = x_all[:split_point], x_all[split_point:]
    y_all_train, y_all_test = y_all[:split_point], y_all[split_point:]
    
    return x_all_train, y_all_train, x_all_test, y_all_test

#define helper funcs
def print_ppv_fpv(cm):
    # the indices here are [col][row] or [actual][guessed]
    TN = cm[False][False]   
    TP = cm[True][True]
    FN = cm[True][False]
    FP = cm[False][True]
    print('Accuracy: ', (TN+TP)/(TN+TP+FN+FP))
    print('PPV: ', TP / (TP + FP))
    print('FPR: ', FP / (FP + TN))
    print('FNR: ', FN / (FN + TP))
    print()

def print_metrics(guessed, actual):
    cm = pd.crosstab(guessed, actual, rownames=['guessed'], colnames=['actual'])
    print(cm)
    print()
    print_ppv_fpv(cm)


x_train, y_train, x_control_train, x_test, y_test, x_control_test = split_into_train_test(X, y, x_control, 0.8)

mlp_model = MLPClassifier(solver='sgd', alpha=1e-5, hidden_layer_sizes=(5, 2), random_state=1)
mlp_model.fit(x_train, y_train)

# Predict
mlp_model_y = mlp_model.predict(x_test)

# Print accuracy
print("Accuracy:", accuracy_score(y_test, mlp_model_y))
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from aif360.datasets import BinaryLabelDataset
from aif360.metrics import ClassificationMetric
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from aif360.metrics import BinaryLabelDatasetMetric
from aif360.algorithms.preprocessing import DisparateImpactRemover
import seaborn as sns
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings('ignore')


rand_seed = 1
np.random.seed(rand_seed)

# Load the data
train = pd.read_csv(r'../Resources/Data/baseline_train_data.csv')
test = pd.read_csv(r'../Resources/Data/baseline_test_data.csv')
valid = pd.read_csv(r'../Resources/Data/baseline_valis_data.csv')

# Define target and features
target = 'two_year_recid'

def calc_prop(data, group_col, group, output_col, output_val):
    new = data[data[group_col] == group]
    return len(new[new[output_col] == output_val])/len(new)

parity_rate_cauc = calc_prop(train, "race", 1, target, 0)
parity_rate_black = calc_prop(train, "race", 0, target, 0)
print("parity_rate_cauc:", parity_rate_cauc)
print("parity_rate_black:", parity_rate_black)
print("parity rate ration black/cauc:", parity_rate_black/parity_rate_cauc)

# Define privileged and unprivileged groups
privileged_groups = [{'race': 1}]
unprivileged_groups = [{'race': 0}]

binary_label_dataset_original = BinaryLabelDataset(df=train, 
                                        label_names=[target], 
                                        protected_attribute_names=['race'],
                                        favorable_label=0, 
                                        unfavorable_label=1,
                                        )

di = BinaryLabelDatasetMetric(binary_label_dataset_original,
                              unprivileged_groups = unprivileged_groups,
                              privileged_groups = privileged_groups
                             ).disparate_impact()

print("Disparate Impact:", di)

df1 = train.copy()



model_features = [col for col in df1.columns if col not in [target]]
model_target = [target]

binary_label_dataset_new = BinaryLabelDataset(df=df1, # from now on, we'll work on the df
                                              label_names=[target], 
                                              protected_attribute_names=['race'],
                                              favorable_label=0, # non-default
                                              unfavorable_label=1, # default label
                                              )

# Calculate disparate impact in the new dataset
di_new= BinaryLabelDatasetMetric(binary_label_dataset_new,
                                 unprivileged_groups = unprivileged_groups,
                                 privileged_groups = privileged_groups
                                ).disparate_impact()

print("Disparate Impact in the new dataset:", di_new)

def apply_dir(rep_lev, bin_label_data):
    di_remover = DisparateImpactRemover(repair_level=rep_lev)
    binary_label_dataset_transformed = di_remover.fit_transform(bin_label_data)
    df_transformed = binary_label_dataset_transformed.convert_to_dataframe()[0] 
    
    return df_transformed

binary_label_dataset = BinaryLabelDataset(df=df1, # Our goal is to transform the df dataset
                                        label_names=[target], 
                                        protected_attribute_names=['race'],
                                        favorable_label=0, # non-default
                                        unfavorable_label=1, # default label
                                        )

df_transformed = apply_dir(0.5, binary_label_dataset)

def calc_prop(data, group_col, group, output_col, output_val):
    new = data[data[group_col] == group]
    return len(new[new[output_col] == output_val])/len(new)

parity_rate_cauc = calc_prop(df_transformed, "race", 1, target, 0)
parity_rate_black = calc_prop(df_transformed, "race", 0, target, 0)
print("parity_rate_cauc:", parity_rate_cauc)
print("parity_rate_black:", parity_rate_black)
print("parity rate ration black/cauc:", parity_rate_black/parity_rate_cauc)

# Separate features and target for training, testing, and validation data
X_train = df_transformed.drop(columns=[target])
y_train = df_transformed[target]

X_test = test.drop(columns=[target])
y_test = test[target]

X_valid = valid.drop(columns=[target])
y_valid = valid[target]

# Define the logistic regression model function
def logistic_model(x_train_transformed, y_train_transformed, x_test_transformed):
    # Initialize Logistic Regression model
    lr_params = {
        "penalty": "l2",  # L2 regularization
        "solver": "liblinear",  # Solver suitable for small datasets
        "random_state": rand_seed,
    }

    lr_dir = Pipeline(
        steps=[
            ("preprocessing", StandardScaler()),
            ("classifier", LogisticRegression(**lr_params)), 
        ]
    )

    lr_dir.fit(x_train_transformed, y_train_transformed.values.ravel())

    y_pred_test_lr_dir = lr_dir.predict(x_test_transformed)

    print(f'Test Accuracy: {accuracy_score(y_test, y_pred_test_lr_dir)}')
    print(confusion_matrix(y_test, y_pred_test_lr_dir))
    
    return y_pred_test_lr_dir

# Function to get results from the model
def get_results(test_df_transformed, y_pred_test_lr_dir):
    all_results = pd.concat(
        [
            test_df_transformed.reset_index(drop=True)[["race", target]],
            pd.Series(y_pred_test_lr_dir, name="y_pred_test_lr_dir"),  
        ],
        axis=1
    )
    return all_results

# Function to generate disparate impact results
def gen_dir_results(test_df, all_results):
    # Convert test_df DataFrame to BinaryLabelDataset
    binary_label_dataset_original_test = BinaryLabelDataset(df=test_df, 
                                                            label_names=[target], 
                                                            protected_attribute_names=['race'],
                                                            favorable_label=0, 
                                                            unfavorable_label=1)

    # Calculate disparate impact in the original test dataset, before applying DIR
    dir_metrics_original_test = BinaryLabelDatasetMetric(binary_label_dataset_original_test,
                                                        unprivileged_groups=unprivileged_groups,
                                                        privileged_groups=privileged_groups).disparate_impact()

    print("Disparate Impact in _original_test:", dir_metrics_original_test)

    # Convert y_pred_test_lr_dir (the model prediction) DataFrame to BinaryLabelDataset
    binary_label_dataset_lr_dir = BinaryLabelDataset(df=all_results, 
                                                     label_names=['y_pred_test_lr_dir'], 
                                                     protected_attribute_names=['race'],
                                                     favorable_label=0, 
                                                     unfavorable_label=1)

    # Calculate disparate impact in the predicted dataset generated by the Logistic Regression
    dir_metrics_lr_dir = BinaryLabelDatasetMetric(binary_label_dataset_lr_dir,
                                                  unprivileged_groups=unprivileged_groups,
                                                  privileged_groups=privileged_groups).disparate_impact()

    print("Disparate Impact in lr_dir:", dir_metrics_lr_dir)



# Prepare datasets for training and testing
x_train_transformed = df_transformed.drop(columns=[target])
y_train_transformed = df_transformed[target]

x_test_transformed = test.drop(columns=[target])
y_test_transformed = test[target]
# Fit and predict using logistic regression
y_pred_test_lr_dir = logistic_model(x_train_transformed, y_train_transformed, x_test_transformed)
all_results = get_results(test, y_pred_test_lr_dir)

# Generate and print disparate impact results
gen_dir_results(test, all_results)
print()

